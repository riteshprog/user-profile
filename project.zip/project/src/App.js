import React from 'react';
import './App.css';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import LoginForm from './LoginForm';
import SearchPlanet from './SearchPlanet'


function App() {
  return (
    <BrowserRouter>
    <Switch>
    <Route path="/" exact component={LoginForm} />
    <Route path="/SearchPlanet" component={SearchPlanet} />
    </Switch>
    </BrowserRouter>
    
    

    
  );
}

export default App;
