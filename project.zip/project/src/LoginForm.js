import React, { Component } from 'react';
//import  { Redirect } from 'react-router-dom'
import logo from './logo.png';
import { Button, Form, Grid, Header, Image, Segment } from 'semantic-ui-react'
//import { browserHistory } from 'react-router-dom'

class LoginForm extends Component {
    constructor(props){
        super(props)
        this.state = {
            email: "",
            password: "",
            formError: {email: '', password: ''},
            emailValid: false,
            passwordValid: false,
            formValid: false,
            persons: null,
            loading: false
            
            


        }
        //console.log(this.persons)
        this.handleName = this.handleName.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

   async componentDidMount(){

       
  
    const url ="https://swapi.co/api/people/";
    //const url =" https://swapi.co/api/people/?search=${event.target.name}`";
    
        const response = await fetch(url);
        const data = await response.json();
        this.setState({loading:true, persons: data.results})
        
        
};

handleName = (event) => {
//console.log(event.target.name)
    this.setState({[event.target.name]: event.target.value});
    event.preventDefault()



}
    
    handleSubmit(event, persons){
    
        event.preventDefault();
        var isLogin= false;
        
        for (var i = 0; i < this.state.persons.length; i++) {

            if( this.state.email === this.state.persons[i].name && 
                this.state.password === this.state.persons[i].birth_year)
            {
              
                isLogin= true;
                break;
    
            }
    
           
        }
        
        if(isLogin===true){
        console.log("login successful");
        //let history = useHistory();
       // props.history.push('/SearchPlanet');
       this.props.history.push('/SearchPlanet');
        
      }
        else{
        this.setState({ email: '', password: '' });
        console.log("login unsuccessful");
      }
    }
       
       
    

    render() {


        const { loading} = this.state;
        
        if(!loading){
            return <div>Loading....</div>
        }
        else{
        return (
<div>

<Grid textAlign='center' style={{ height: '100vh' }} verticalAlign='middle'>
    <Grid.Column style={{ maxWidth: 450 }}>
      <Header as='h2' color='teal' textAlign='center'>
        <Image src={logo} /> Log-in to your account
      </Header>
      <Form size='large'>
        <Segment stacked>
          <Form.Input 
          required
          fluid 
          icon='user' 
          iconPosition='left' 
          name="email" 
          value={this.state.email} 
          onChange={this.handleName}
          placeholder='Enter E-mail Name' />
         
         
         
          <Form.Input
            fluid
            required
            icon='lock'
            iconPosition='left'
            password='password'
            placeholder="Enter Password"
            type='password'
            name="password"
            value={this.state.password}  onChange={this.handleName}
          />

          <Button color='teal' fluid size='large'  onClick={this.handleSubmit}>
            Login
          </Button>
        </Segment>
      </Form>
         </Grid.Column>
  </Grid>
  </div>
    )
    }
}
}
export default LoginForm