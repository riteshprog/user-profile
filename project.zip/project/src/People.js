import React, { Component } from 'react'

export default class People extends Component {
    constructor(props){
        super(props)
        this.state = {       
            people: [],
            loading: false
        }
         }

   async componentDidMount(){

       
  
    const urldata ="https://swapi.co/api/people/1";
    
    //const url =" https://swapi.co/api/people/?search=${event.target.name}`";
    
        const response = await fetch(urldata);
        const data = await response.json();
        this.setState({ people: data})
        
        
};

    render() {
        
        return (
            <div>
                <pre>
                {JSON.stringify(this.state.people, null, 2)}
                </pre>
            </div>
        )
    }
}
