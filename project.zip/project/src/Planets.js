import React, { Component } from 'react'

export default class Planets extends Component {
    constructor(props){
        super(props)
        this.state = {       
            planets: [],
            
        }
         }

   async componentDidMount(){

       
  
    const urldata ="https://swapi.co/api/planets/3";
    //const url =" https://swapi.co/api/people/?search=${event.target.name}`";
    
        const response = await fetch(urldata);
        const data = await response.json();
        this.setState({planets: data})
        
        
};

    render() {
        
        return (
            <div>
                <pre>
                {JSON.stringify(this.state.planets, null, 2)}
                </pre>
            </div>
        )
    }
}


