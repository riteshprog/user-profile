import React, { Component } from 'react';
import {Link} from 'react-router-dom';
import './App.css';
import { Search, Grid} from 'semantic-ui-react';
import Planets from './Planets';
import People from './People';
import Starships from './Starships';



export default class SearchPlanet extends Component {
  constructor(){
    super()
      this.state = 
      { 
        query: "",
        people: [],
        show: [false, false,false]
        
      }
    
  }
  onChange = e => {
    debugger;
    var { value } = e.target;
    if(value.indexOf("people") !== -1)
    value= 1;
    this.setState({
      query: value
    });
    debugger;
    this.search(value);
  };

       search = query => {
       var url;
       var  urlPeople = `https://swapi.co/api/people?search=${query}`
       //var urlplanet = `https://swapi.co/api/planet?search=${query}`
        // urlPeople = `https://swapi.co/api/people?search=${query}`
        //  if(this.state.query.indexOf("people") !== -1)
       url= urlPeople;
          const token = {};
          this.token = token;
         // console.log(url);
     // console.log(url + `${query}`);
          fetch(url)
            .then(results => results.json())
            .then(data => {
              if (this.token === token) {
                this.setState({ people: data.results });
              }
            });
        };
      
        componentDidMount() {
          this.search("");
        }


 /* handleSearchChange = (e, { value }) => {
    this.setState({ isLoading: true, value })

    
  }*/


    render() {
        return (
          <div>
            <div className="search-box">
                 <Grid>
                  <Grid.Column width={16}>
                  <span className="input-group-addon">https://swapi.co/api/</span>
                  <Search  name="search"
                  
                  onChange={this.onChange}
                  
           
                 />
                   <small>Need a hint? try &#160;&#160;&#160;
                     <button onClick={()=>this.showHide(0)}>people/1/</button> &#160;&#160;&#160;or &#160;&#160;&#160;
                     <button onClick={()=>this.showHide(1)}>planets/3/</button> &#160;&#160;&#160;or &#160;&#160;&#160;
                     <button onClick={()=>this.showHide(2)}>starships/9/</button> &#160;&#160;&#160;or &#160;&#160;&#160;
                     <Link to="/">Login Page</Link>
                    </small>
        
          
        </Grid.Column>
        </Grid>
        </div>

        <div className="result-data search-box">
         {this.state.show[0] &&
          <div id="001"><People /></div> 
        }
        {this.state.show[1] &&
          <div id="002"><Planets /></div>
        }
        {this.state.show[2] &&
          <div id="003"><Starships /></div>
        }
        </div>

      </div>
        )
    }
    /*changeName(){
      let text = "text "
      text += this.state.show === true ? "hide" : "show";
      return text;
  }*/
  showHide(num){
      this.setState((prevState) => {
          const newItems = [...prevState.show];
          newItems[num] = !newItems[num];
          return {show: newItems};
      });
      if(this.state.show === true){
        return false
      }
  }
}
