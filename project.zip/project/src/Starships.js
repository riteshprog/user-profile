import React, { Component } from 'react'

export default class Starships extends Component {
    constructor(props){
        super(props)
        this.state = {       
            starships: []
        }
         }

   async componentDidMount(){

       
  
    const urldata ="https://swapi.co/api/starships/9";
    //const url =" https://swapi.co/api/people/?search=${event.target.name}`";
    
        const response = await fetch(urldata);
        const data = await response.json();
        this.setState({ starships: data})
        
        
        
};

    render() {
        
        return (
            <div>
                <pre>
                {JSON.stringify(this.state.starships, null, 2)}
                </pre>
            </div>
        )
    }
}
